﻿namespace Курсовая_Работа
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.openFileDialogPhotePath = new System.Windows.Forms.OpenFileDialog();
            this.openFileDialogBarCode = new System.Windows.Forms.OpenFileDialog();
            this.comboBoxCPorder = new System.Windows.Forms.ComboBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.textBoxCountListOrder = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.dateTimePickerOrder = new System.Windows.Forms.DateTimePicker();
            this.buttonAddCPorder = new System.Windows.Forms.Button();
            this.buttonNextOrder = new System.Windows.Forms.Button();
            this.buttonRemoveOrder = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.buttonAddInvoice = new System.Windows.Forms.Button();
            this.buttonAddOrder = new System.Windows.Forms.Button();
            this.ColumnProduct = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnDeliveDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.columnSupplier = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnTrans = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.buttonSaveCP = new System.Windows.Forms.Button();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.buttonRemoveCP = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.tabPageCounterparty = new System.Windows.Forms.TabPage();
            this.InputCounterparty = new System.Windows.Forms.Panel();
            this.label53 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.label52 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.tBPhone = new System.Windows.Forms.MaskedTextBox();
            this.btnRemoveCP = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.tBINN = new System.Windows.Forms.TextBox();
            this.labelAcc = new System.Windows.Forms.Label();
            this.tBBancAcc = new System.Windows.Forms.TextBox();
            this.labelbankName = new System.Windows.Forms.Label();
            this.tBNameBank = new System.Windows.Forms.TextBox();
            this.labelEmail = new System.Windows.Forms.Label();
            this.tBEmail = new System.Windows.Forms.TextBox();
            this.labelPhone = new System.Windows.Forms.Label();
            this.labelAddress = new System.Windows.Forms.Label();
            this.tBAddress = new System.Windows.Forms.TextBox();
            this.labelFullNameDirector = new System.Windows.Forms.Label();
            this.tBFullNameDirector = new System.Windows.Forms.TextBox();
            this.labelCountry = new System.Windows.Forms.Label();
            this.tBCountry = new System.Windows.Forms.TextBox();
            this.labelFirmName = new System.Windows.Forms.Label();
            this.tBFirmName = new System.Windows.Forms.TextBox();
            this.buttonSaveCounterparty = new System.Windows.Forms.Button();
            this.BtnAddCounterparty = new System.Windows.Forms.Button();
            this.GridCounterparty = new System.Windows.Forms.DataGridView();
            this.ColumnFirmName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnCountry = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnDirectorName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnLegalAddress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnPhone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnEmail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnBankName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnBankAccount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnINN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageTransaction = new System.Windows.Forms.TabPage();
            this.panelTransaction = new System.Windows.Forms.Panel();
            this.labelCP = new System.Windows.Forms.Label();
            this.labelDate = new System.Windows.Forms.Label();
            this.buttonRemoveInvoice = new System.Windows.Forms.Button();
            this.buttonSaveTransaction = new System.Windows.Forms.Button();
            this.buttonAddNewCp = new System.Windows.Forms.Button();
            this.dateTimTransaction = new System.Windows.Forms.DateTimePicker();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.comboBoxCounterpartyTransaction = new System.Windows.Forms.ComboBox();
            this.groupBoxCP = new System.Windows.Forms.GroupBox();
            this.textBoxCountryCP = new System.Windows.Forms.TextBox();
            this.maskedTextBoxPhone = new System.Windows.Forms.MaskedTextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.textBoxFirmNameCP = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.textBoxINNCP = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxFullName = new System.Windows.Forms.TextBox();
            this.textBoxBankAccCP = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxAddress = new System.Windows.Forms.TextBox();
            this.textBoxBankNameCP = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxEmailCP = new System.Windows.Forms.TextBox();
            this.groupBoxInvoice = new System.Windows.Forms.GroupBox();
            this.gridReceivedProducts = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBoxUnitInvoice = new System.Windows.Forms.ComboBox();
            this.textBoxManufactInvoice = new System.Windows.Forms.TextBox();
            this.buttonBarcodeInvoice = new System.Windows.Forms.Button();
            this.label40 = new System.Windows.Forms.Label();
            this.textBoxPriceInvoice = new System.Windows.Forms.TextBox();
            this.buttonNextProduct = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.buttonPhotoInvoice = new System.Windows.Forms.Button();
            this.textBoxCountInvoice = new System.Windows.Forms.TextBox();
            this.textBoxNameProductInvoice = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.textBoxShelfLifeINvoice = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.buttonDeleteProductList = new System.Windows.Forms.Button();
            this.label38 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.comboBoxGroupInvoice = new System.Windows.Forms.ComboBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.panelOrder = new System.Windows.Forms.GroupBox();
            this.label50 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label35 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label48 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label45 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewImageColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewImageColumn();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.buttonCompleteOrder = new System.Windows.Forms.Button();
            this.buttonRemoveProductOrder = new System.Windows.Forms.Button();
            this.buttonLeaveTransaction = new System.Windows.Forms.Button();
            this.buttondeleteTransaction = new System.Windows.Forms.Button();
            this.panelMenu = new System.Windows.Forms.Panel();
            this.label33 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.buttonAddTrans = new System.Windows.Forms.Button();
            this.GridTrsnsaction = new System.Windows.Forms.DataGridView();
            this.ColumType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnCP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageWarehouse = new System.Windows.Forms.TabPage();
            this.panelProduct = new System.Windows.Forms.Panel();
            this.buttonDeleteProduct = new System.Windows.Forms.Button();
            this.labelTitleProduct = new System.Windows.Forms.Label();
            this.comboBoxUnit = new System.Windows.Forms.ComboBox();
            this.pictureBoxBarcode = new System.Windows.Forms.PictureBox();
            this.pictureBoxPhote = new System.Windows.Forms.PictureBox();
            this.comboBoxProductGroup = new System.Windows.Forms.ComboBox();
            this.buttonBarcode = new System.Windows.Forms.Button();
            this.buttonRemoveProduct = new System.Windows.Forms.Button();
            this.buttonSaveProduct = new System.Windows.Forms.Button();
            this.btnPhotoPath = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePickerDeliveryDate = new System.Windows.Forms.DateTimePicker();
            this.labelDeliveryDate = new System.Windows.Forms.Label();
            this.labelgroup = new System.Windows.Forms.Label();
            this.textBoxPurchasePrice = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxCountProduct = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxManufactory = new System.Windows.Forms.TextBox();
            this.labelManufuc = new System.Windows.Forms.Label();
            this.textBoxShelfLife = new System.Windows.Forms.TextBox();
            this.labelDelDate = new System.Windows.Forms.Label();
            this.textBoxNameProduct = new System.Windows.Forms.TextBox();
            this.labelNamePr = new System.Windows.Forms.Label();
            this.buttonAddProduct = new System.Windows.Forms.Button();
            this.GridWareHouse = new System.Windows.Forms.DataGridView();
            this.ColumnProductName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnProductGroup = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnDeliveryDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnShelfLife = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnManufacturer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnUnit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnPurchasePrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnBarcode = new System.Windows.Forms.DataGridViewImageColumn();
            this.ColumnPhotoPath = new System.Windows.Forms.DataGridViewImageColumn();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPageCounterparty.SuspendLayout();
            this.InputCounterparty.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridCounterparty)).BeginInit();
            this.tabPageTransaction.SuspendLayout();
            this.panelTransaction.SuspendLayout();
            this.groupBoxCP.SuspendLayout();
            this.groupBoxInvoice.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridReceivedProducts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panelOrder.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panelMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridTrsnsaction)).BeginInit();
            this.tabPageWarehouse.SuspendLayout();
            this.panelProduct.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBarcode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPhote)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridWareHouse)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // openFileDialogPhotePath
            // 
            this.openFileDialogPhotePath.AddExtension = false;
            this.openFileDialogPhotePath.AutoUpgradeEnabled = false;
            this.openFileDialogPhotePath.CheckPathExists = false;
            this.openFileDialogPhotePath.DereferenceLinks = false;
            this.openFileDialogPhotePath.FileName = "PhoteProduct";
            this.openFileDialogPhotePath.Filter = "Файлы изображений (*.jpg)|*.jpg;";
            this.openFileDialogPhotePath.InitialDirectory = "Курсовая_Работа\\bin\\Debug\\Product";
            // 
            // openFileDialogBarCode
            // 
            this.openFileDialogBarCode.AddExtension = false;
            this.openFileDialogBarCode.AutoUpgradeEnabled = false;
            this.openFileDialogBarCode.CheckPathExists = false;
            this.openFileDialogBarCode.DereferenceLinks = false;
            this.openFileDialogBarCode.FileName = "Barcode";
            this.openFileDialogBarCode.Filter = "Файлы изображений (*.png)|*.png";
            this.openFileDialogBarCode.InitialDirectory = "Курсовая_Работа\\bin\\Debug";
            // 
            // comboBoxCPorder
            // 
            this.comboBoxCPorder.FormattingEnabled = true;
            this.comboBoxCPorder.Location = new System.Drawing.Point(70, 68);
            this.comboBoxCPorder.Name = "comboBoxCPorder";
            this.comboBoxCPorder.Size = new System.Drawing.Size(208, 24);
            this.comboBoxCPorder.TabIndex = 0;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(65, 30);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(0, 26);
            this.label31.TabIndex = 1;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(108, 204);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(0, 26);
            this.label30.TabIndex = 3;
            // 
            // textBoxCountListOrder
            // 
            this.textBoxCountListOrder.Location = new System.Drawing.Point(118, 348);
            this.textBoxCountListOrder.Name = "textBoxCountListOrder";
            this.textBoxCountListOrder.Size = new System.Drawing.Size(118, 22);
            this.textBoxCountListOrder.TabIndex = 4;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(40, 307);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(0, 26);
            this.label29.TabIndex = 5;
            // 
            // dateTimePickerOrder
            // 
            this.dateTimePickerOrder.CustomFormat = "";
            this.dateTimePickerOrder.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerOrder.Location = new System.Drawing.Point(113, 241);
            this.dateTimePickerOrder.Name = "dateTimePickerOrder";
            this.dateTimePickerOrder.Size = new System.Drawing.Size(123, 22);
            this.dateTimePickerOrder.TabIndex = 15;
            // 
            // buttonAddCPorder
            // 
            this.buttonAddCPorder.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonAddCPorder.Location = new System.Drawing.Point(70, 112);
            this.buttonAddCPorder.Name = "buttonAddCPorder";
            this.buttonAddCPorder.Size = new System.Drawing.Size(208, 70);
            this.buttonAddCPorder.TabIndex = 5;
            this.buttonAddCPorder.Text = "Добавить нового заказчика";
            this.buttonAddCPorder.UseVisualStyleBackColor = true;
            // 
            // buttonNextOrder
            // 
            this.buttonNextOrder.Location = new System.Drawing.Point(179, 388);
            this.buttonNextOrder.Name = "buttonNextOrder";
            this.buttonNextOrder.Size = new System.Drawing.Size(183, 89);
            this.buttonNextOrder.TabIndex = 20;
            this.buttonNextOrder.Text = "Продолжить";
            this.buttonNextOrder.UseVisualStyleBackColor = true;
            // 
            // buttonRemoveOrder
            // 
            this.buttonRemoveOrder.Location = new System.Drawing.Point(3, 388);
            this.buttonRemoveOrder.Name = "buttonRemoveOrder";
            this.buttonRemoveOrder.Size = new System.Drawing.Size(173, 89);
            this.buttonRemoveOrder.TabIndex = 21;
            this.buttonRemoveOrder.Text = "Удалить";
            this.buttonRemoveOrder.UseVisualStyleBackColor = true;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(27, 21);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(0, 22);
            this.label28.TabIndex = 8;
            // 
            // buttonAddInvoice
            // 
            this.buttonAddInvoice.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonAddInvoice.Location = new System.Drawing.Point(31, 66);
            this.buttonAddInvoice.Name = "buttonAddInvoice";
            this.buttonAddInvoice.Size = new System.Drawing.Size(219, 56);
            this.buttonAddInvoice.TabIndex = 6;
            this.buttonAddInvoice.Text = "Накладная";
            this.buttonAddInvoice.UseVisualStyleBackColor = true;
            // 
            // buttonAddOrder
            // 
            this.buttonAddOrder.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonAddOrder.Location = new System.Drawing.Point(31, 143);
            this.buttonAddOrder.Name = "buttonAddOrder";
            this.buttonAddOrder.Size = new System.Drawing.Size(219, 56);
            this.buttonAddOrder.TabIndex = 7;
            this.buttonAddOrder.Text = "Заказ";
            this.buttonAddOrder.UseVisualStyleBackColor = true;
            // 
            // ColumnProduct
            // 
            this.ColumnProduct.FillWeight = 140F;
            this.ColumnProduct.HeaderText = "Список товаров";
            this.ColumnProduct.MinimumWidth = 6;
            this.ColumnProduct.Name = "ColumnProduct";
            this.ColumnProduct.ReadOnly = true;
            this.ColumnProduct.Width = 125;
            // 
            // ColumnDeliveDate
            // 
            this.ColumnDeliveDate.FillWeight = 80F;
            this.ColumnDeliveDate.HeaderText = "Дата оформления";
            this.ColumnDeliveDate.MinimumWidth = 6;
            this.ColumnDeliveDate.Name = "ColumnDeliveDate";
            this.ColumnDeliveDate.ReadOnly = true;
            this.ColumnDeliveDate.Width = 125;
            // 
            // columnSupplier
            // 
            this.columnSupplier.FillWeight = 80F;
            this.columnSupplier.HeaderText = "Контрагент";
            this.columnSupplier.MinimumWidth = 6;
            this.columnSupplier.Name = "columnSupplier";
            this.columnSupplier.ReadOnly = true;
            this.columnSupplier.Width = 125;
            // 
            // ColumnTrans
            // 
            this.ColumnTrans.FillWeight = 60F;
            this.ColumnTrans.HeaderText = "Вид операции";
            this.ColumnTrans.MinimumWidth = 6;
            this.ColumnTrans.Name = "ColumnTrans";
            this.ColumnTrans.ReadOnly = true;
            this.ColumnTrans.Width = 125;
            // 
            // buttonSaveCP
            // 
            this.buttonSaveCP.Location = new System.Drawing.Point(545, 415);
            this.buttonSaveCP.Name = "buttonSaveCP";
            this.buttonSaveCP.Size = new System.Drawing.Size(245, 87);
            this.buttonSaveCP.TabIndex = 0;
            this.buttonSaveCP.Text = "Сохранить";
            this.buttonSaveCP.UseVisualStyleBackColor = true;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(21, 66);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(0, 26);
            this.label26.TabIndex = 2;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(21, 140);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(0, 26);
            this.label25.TabIndex = 4;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(21, 213);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(0, 26);
            this.label24.TabIndex = 6;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(21, 276);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(0, 26);
            this.label23.TabIndex = 8;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(21, 348);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(0, 26);
            this.label22.TabIndex = 10;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(540, 66);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(0, 26);
            this.label21.TabIndex = 12;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(540, 143);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(0, 26);
            this.label20.TabIndex = 14;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(540, 227);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(0, 26);
            this.label19.TabIndex = 16;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(540, 316);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(0, 26);
            this.label18.TabIndex = 18;
            // 
            // buttonRemoveCP
            // 
            this.buttonRemoveCP.Location = new System.Drawing.Point(0, 0);
            this.buttonRemoveCP.Name = "buttonRemoveCP";
            this.buttonRemoveCP.Size = new System.Drawing.Size(75, 23);
            this.buttonRemoveCP.TabIndex = 0;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(372, 18);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(0, 26);
            this.label27.TabIndex = 20;
            // 
            // tabPageCounterparty
            // 
            this.tabPageCounterparty.BackColor = System.Drawing.Color.Transparent;
            this.tabPageCounterparty.Controls.Add(this.InputCounterparty);
            this.tabPageCounterparty.Controls.Add(this.BtnAddCounterparty);
            this.tabPageCounterparty.Controls.Add(this.GridCounterparty);
            this.tabPageCounterparty.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabPageCounterparty.Location = new System.Drawing.Point(4, 64);
            this.tabPageCounterparty.Name = "tabPageCounterparty";
            this.tabPageCounterparty.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageCounterparty.Size = new System.Drawing.Size(1504, 431);
            this.tabPageCounterparty.TabIndex = 2;
            this.tabPageCounterparty.Text = "Контрагенты";
            // 
            // InputCounterparty
            // 
            this.InputCounterparty.BackColor = System.Drawing.Color.White;
            this.InputCounterparty.Controls.Add(this.label53);
            this.InputCounterparty.Controls.Add(this.button3);
            this.InputCounterparty.Controls.Add(this.label52);
            this.InputCounterparty.Controls.Add(this.label51);
            this.InputCounterparty.Controls.Add(this.tBPhone);
            this.InputCounterparty.Controls.Add(this.btnRemoveCP);
            this.InputCounterparty.Controls.Add(this.label9);
            this.InputCounterparty.Controls.Add(this.tBINN);
            this.InputCounterparty.Controls.Add(this.labelAcc);
            this.InputCounterparty.Controls.Add(this.tBBancAcc);
            this.InputCounterparty.Controls.Add(this.labelbankName);
            this.InputCounterparty.Controls.Add(this.tBNameBank);
            this.InputCounterparty.Controls.Add(this.labelEmail);
            this.InputCounterparty.Controls.Add(this.tBEmail);
            this.InputCounterparty.Controls.Add(this.labelPhone);
            this.InputCounterparty.Controls.Add(this.labelAddress);
            this.InputCounterparty.Controls.Add(this.tBAddress);
            this.InputCounterparty.Controls.Add(this.labelFullNameDirector);
            this.InputCounterparty.Controls.Add(this.tBFullNameDirector);
            this.InputCounterparty.Controls.Add(this.labelCountry);
            this.InputCounterparty.Controls.Add(this.tBCountry);
            this.InputCounterparty.Controls.Add(this.labelFirmName);
            this.InputCounterparty.Controls.Add(this.tBFirmName);
            this.InputCounterparty.Controls.Add(this.buttonSaveCounterparty);
            this.InputCounterparty.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.InputCounterparty.Location = new System.Drawing.Point(0, 0);
            this.InputCounterparty.Name = "InputCounterparty";
            this.InputCounterparty.Size = new System.Drawing.Size(1508, 524);
            this.InputCounterparty.TabIndex = 1;
            this.InputCounterparty.Visible = false;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(579, 31);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(251, 26);
            this.label53.TabIndex = 24;
            this.label53.Text = "Добавление контрагента";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(1178, 166);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(203, 114);
            this.button3.TabIndex = 23;
            this.button3.Text = "Удалить";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Visible = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(1073, 244);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(0, 26);
            this.label52.TabIndex = 22;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(1073, 187);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(0, 26);
            this.label51.TabIndex = 21;
            // 
            // tBPhone
            // 
            this.tBPhone.Location = new System.Drawing.Point(310, 301);
            this.tBPhone.Mask = "+0000-(999)-0000-0000";
            this.tBPhone.Name = "tBPhone";
            this.tBPhone.Size = new System.Drawing.Size(236, 34);
            this.tBPhone.TabIndex = 20;
            // 
            // btnRemoveCP
            // 
            this.btnRemoveCP.Location = new System.Drawing.Point(1178, 166);
            this.btnRemoveCP.Name = "btnRemoveCP";
            this.btnRemoveCP.Size = new System.Drawing.Size(203, 114);
            this.btnRemoveCP.TabIndex = 19;
            this.btnRemoveCP.Text = "Сбросить веденные данные";
            this.btnRemoveCP.UseVisualStyleBackColor = true;
            this.btnRemoveCP.Click += new System.EventHandler(this.btnRemoveCP_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(628, 268);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(138, 26);
            this.label9.TabIndex = 18;
            this.label9.Text = "ИНН фирмы:";
            // 
            // tBINN
            // 
            this.tBINN.Location = new System.Drawing.Point(826, 260);
            this.tBINN.Name = "tBINN";
            this.tBINN.Size = new System.Drawing.Size(226, 34);
            this.tBINN.TabIndex = 17;
            this.tBINN.TextChanged += new System.EventHandler(this.tBINN_TextChanged);
            // 
            // labelAcc
            // 
            this.labelAcc.AutoSize = true;
            this.labelAcc.Location = new System.Drawing.Point(628, 208);
            this.labelAcc.Name = "labelAcc";
            this.labelAcc.Size = new System.Drawing.Size(140, 26);
            this.labelAcc.TabIndex = 16;
            this.labelAcc.Text = "Номер счета:";
            // 
            // tBBancAcc
            // 
            this.tBBancAcc.Location = new System.Drawing.Point(826, 200);
            this.tBBancAcc.Name = "tBBancAcc";
            this.tBBancAcc.Size = new System.Drawing.Size(226, 34);
            this.tBBancAcc.TabIndex = 15;
            this.tBBancAcc.TextChanged += new System.EventHandler(this.tBBancAcc_TextChanged);
            // 
            // labelbankName
            // 
            this.labelbankName.AutoSize = true;
            this.labelbankName.Location = new System.Drawing.Point(628, 148);
            this.labelbankName.Name = "labelbankName";
            this.labelbankName.Size = new System.Drawing.Size(168, 26);
            this.labelbankName.TabIndex = 14;
            this.labelbankName.Text = "Название банка:";
            // 
            // tBNameBank
            // 
            this.tBNameBank.Location = new System.Drawing.Point(826, 140);
            this.tBNameBank.Name = "tBNameBank";
            this.tBNameBank.Size = new System.Drawing.Size(226, 34);
            this.tBNameBank.TabIndex = 13;
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.Location = new System.Drawing.Point(628, 90);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(79, 26);
            this.labelEmail.TabIndex = 12;
            this.labelEmail.Text = "E-mail:";
            // 
            // tBEmail
            // 
            this.tBEmail.Location = new System.Drawing.Point(826, 82);
            this.tBEmail.Name = "tBEmail";
            this.tBEmail.Size = new System.Drawing.Size(226, 34);
            this.tBEmail.TabIndex = 11;
            // 
            // labelPhone
            // 
            this.labelPhone.AutoSize = true;
            this.labelPhone.Location = new System.Drawing.Point(99, 303);
            this.labelPhone.Name = "labelPhone";
            this.labelPhone.Size = new System.Drawing.Size(101, 26);
            this.labelPhone.TabIndex = 10;
            this.labelPhone.Text = "Телефон:";
            // 
            // labelAddress
            // 
            this.labelAddress.AutoSize = true;
            this.labelAddress.Location = new System.Drawing.Point(99, 253);
            this.labelAddress.Name = "labelAddress";
            this.labelAddress.Size = new System.Drawing.Size(219, 26);
            this.labelAddress.TabIndex = 8;
            this.labelAddress.Text = "Юридический адрес:";
            // 
            // tBAddress
            // 
            this.tBAddress.Location = new System.Drawing.Point(324, 248);
            this.tBAddress.Name = "tBAddress";
            this.tBAddress.Size = new System.Drawing.Size(222, 34);
            this.tBAddress.TabIndex = 7;
            // 
            // labelFullNameDirector
            // 
            this.labelFullNameDirector.AutoSize = true;
            this.labelFullNameDirector.Location = new System.Drawing.Point(99, 198);
            this.labelFullNameDirector.Name = "labelFullNameDirector";
            this.labelFullNameDirector.Size = new System.Drawing.Size(207, 26);
            this.labelFullNameDirector.TabIndex = 6;
            this.labelFullNameDirector.Text = "ФИО руководителя:";
            // 
            // tBFullNameDirector
            // 
            this.tBFullNameDirector.Location = new System.Drawing.Point(324, 193);
            this.tBFullNameDirector.Name = "tBFullNameDirector";
            this.tBFullNameDirector.Size = new System.Drawing.Size(222, 34);
            this.tBFullNameDirector.TabIndex = 5;
            // 
            // labelCountry
            // 
            this.labelCountry.AutoSize = true;
            this.labelCountry.Location = new System.Drawing.Point(99, 145);
            this.labelCountry.Name = "labelCountry";
            this.labelCountry.Size = new System.Drawing.Size(162, 26);
            this.labelCountry.TabIndex = 4;
            this.labelCountry.Text = "Страна фирмы:";
            // 
            // tBCountry
            // 
            this.tBCountry.Location = new System.Drawing.Point(324, 140);
            this.tBCountry.Name = "tBCountry";
            this.tBCountry.Size = new System.Drawing.Size(222, 34);
            this.tBCountry.TabIndex = 3;
            // 
            // labelFirmName
            // 
            this.labelFirmName.AutoSize = true;
            this.labelFirmName.Location = new System.Drawing.Point(99, 90);
            this.labelFirmName.Name = "labelFirmName";
            this.labelFirmName.Size = new System.Drawing.Size(182, 26);
            this.labelFirmName.TabIndex = 2;
            this.labelFirmName.Text = "Название фирмы:";
            // 
            // tBFirmName
            // 
            this.tBFirmName.Location = new System.Drawing.Point(324, 85);
            this.tBFirmName.Name = "tBFirmName";
            this.tBFirmName.Size = new System.Drawing.Size(222, 34);
            this.tBFirmName.TabIndex = 1;
            // 
            // buttonSaveCounterparty
            // 
            this.buttonSaveCounterparty.Location = new System.Drawing.Point(1178, 41);
            this.buttonSaveCounterparty.Name = "buttonSaveCounterparty";
            this.buttonSaveCounterparty.Size = new System.Drawing.Size(203, 114);
            this.buttonSaveCounterparty.TabIndex = 0;
            this.buttonSaveCounterparty.Text = "Сохранить";
            this.buttonSaveCounterparty.UseVisualStyleBackColor = true;
            this.buttonSaveCounterparty.Click += new System.EventHandler(this.buttonSaveCounterparty_Click);
            // 
            // BtnAddCounterparty
            // 
            this.BtnAddCounterparty.Location = new System.Drawing.Point(619, 347);
            this.BtnAddCounterparty.Name = "BtnAddCounterparty";
            this.BtnAddCounterparty.Size = new System.Drawing.Size(270, 81);
            this.BtnAddCounterparty.TabIndex = 2;
            this.BtnAddCounterparty.Text = "Добавить контрагента";
            this.BtnAddCounterparty.UseVisualStyleBackColor = true;
            this.BtnAddCounterparty.Click += new System.EventHandler(this.BtnAddCounterparty_Click);
            // 
            // GridCounterparty
            // 
            this.GridCounterparty.AllowUserToAddRows = false;
            this.GridCounterparty.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.GridCounterparty.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.GridCounterparty.BackgroundColor = System.Drawing.SystemColors.ControlDark;
            this.GridCounterparty.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.GridCounterparty.ColumnHeadersHeight = 90;
            this.GridCounterparty.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.GridCounterparty.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnFirmName,
            this.ColumnCountry,
            this.ColumnDirectorName,
            this.ColumnLegalAddress,
            this.ColumnPhone,
            this.ColumnEmail,
            this.ColumnBankName,
            this.ColumnBankAccount,
            this.ColumnINN});
            this.GridCounterparty.Dock = System.Windows.Forms.DockStyle.Fill;
            this.GridCounterparty.Location = new System.Drawing.Point(3, 3);
            this.GridCounterparty.Name = "GridCounterparty";
            this.GridCounterparty.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.GridCounterparty.RowHeadersVisible = false;
            this.GridCounterparty.RowHeadersWidth = 51;
            this.GridCounterparty.RowTemplate.Height = 24;
            this.GridCounterparty.Size = new System.Drawing.Size(1498, 425);
            this.GridCounterparty.TabIndex = 0;
            this.GridCounterparty.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GridCounterparty_CellClick);
            // 
            // ColumnFirmName
            // 
            this.ColumnFirmName.HeaderText = "Название фирмы";
            this.ColumnFirmName.MinimumWidth = 6;
            this.ColumnFirmName.Name = "ColumnFirmName";
            this.ColumnFirmName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ColumnCountry
            // 
            this.ColumnCountry.HeaderText = "Страна";
            this.ColumnCountry.MinimumWidth = 6;
            this.ColumnCountry.Name = "ColumnCountry";
            this.ColumnCountry.ReadOnly = true;
            this.ColumnCountry.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ColumnCountry.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ColumnDirectorName
            // 
            this.ColumnDirectorName.HeaderText = "Руководитель";
            this.ColumnDirectorName.MinimumWidth = 6;
            this.ColumnDirectorName.Name = "ColumnDirectorName";
            this.ColumnDirectorName.ReadOnly = true;
            this.ColumnDirectorName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ColumnLegalAddress
            // 
            this.ColumnLegalAddress.HeaderText = "Юридический адрес";
            this.ColumnLegalAddress.MinimumWidth = 40;
            this.ColumnLegalAddress.Name = "ColumnLegalAddress";
            this.ColumnLegalAddress.ReadOnly = true;
            this.ColumnLegalAddress.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ColumnPhone
            // 
            this.ColumnPhone.HeaderText = "Телефон";
            this.ColumnPhone.MinimumWidth = 6;
            this.ColumnPhone.Name = "ColumnPhone";
            this.ColumnPhone.ReadOnly = true;
            this.ColumnPhone.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ColumnEmail
            // 
            this.ColumnEmail.HeaderText = "E-mail";
            this.ColumnEmail.MinimumWidth = 6;
            this.ColumnEmail.Name = "ColumnEmail";
            this.ColumnEmail.ReadOnly = true;
            this.ColumnEmail.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ColumnBankName
            // 
            this.ColumnBankName.HeaderText = "Банк";
            this.ColumnBankName.MinimumWidth = 6;
            this.ColumnBankName.Name = "ColumnBankName";
            this.ColumnBankName.ReadOnly = true;
            this.ColumnBankName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ColumnBankAccount
            // 
            this.ColumnBankAccount.HeaderText = "Номер счета";
            this.ColumnBankAccount.MinimumWidth = 6;
            this.ColumnBankAccount.Name = "ColumnBankAccount";
            this.ColumnBankAccount.ReadOnly = true;
            this.ColumnBankAccount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ColumnINN
            // 
            this.ColumnINN.HeaderText = "ИНН";
            this.ColumnINN.MinimumWidth = 6;
            this.ColumnINN.Name = "ColumnINN";
            this.ColumnINN.ReadOnly = true;
            this.ColumnINN.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // tabPageTransaction
            // 
            this.tabPageTransaction.BackColor = System.Drawing.Color.Transparent;
            this.tabPageTransaction.Controls.Add(this.panelTransaction);
            this.tabPageTransaction.Controls.Add(this.buttonLeaveTransaction);
            this.tabPageTransaction.Controls.Add(this.buttondeleteTransaction);
            this.tabPageTransaction.Controls.Add(this.panelMenu);
            this.tabPageTransaction.Controls.Add(this.buttonAddTrans);
            this.tabPageTransaction.Controls.Add(this.GridTrsnsaction);
            this.tabPageTransaction.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabPageTransaction.Location = new System.Drawing.Point(4, 64);
            this.tabPageTransaction.Name = "tabPageTransaction";
            this.tabPageTransaction.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageTransaction.Size = new System.Drawing.Size(1504, 431);
            this.tabPageTransaction.TabIndex = 1;
            this.tabPageTransaction.Text = "Операции";
            // 
            // panelTransaction
            // 
            this.panelTransaction.BackColor = System.Drawing.Color.White;
            this.panelTransaction.Controls.Add(this.labelCP);
            this.panelTransaction.Controls.Add(this.labelDate);
            this.panelTransaction.Controls.Add(this.buttonRemoveInvoice);
            this.panelTransaction.Controls.Add(this.buttonSaveTransaction);
            this.panelTransaction.Controls.Add(this.buttonAddNewCp);
            this.panelTransaction.Controls.Add(this.dateTimTransaction);
            this.panelTransaction.Controls.Add(this.label17);
            this.panelTransaction.Controls.Add(this.label16);
            this.panelTransaction.Controls.Add(this.label15);
            this.panelTransaction.Controls.Add(this.comboBoxCounterpartyTransaction);
            this.panelTransaction.Controls.Add(this.groupBoxCP);
            this.panelTransaction.Controls.Add(this.groupBoxInvoice);
            this.panelTransaction.Controls.Add(this.panelOrder);
            this.panelTransaction.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.panelTransaction.Location = new System.Drawing.Point(0, -1);
            this.panelTransaction.Name = "panelTransaction";
            this.panelTransaction.Size = new System.Drawing.Size(1508, 468);
            this.panelTransaction.TabIndex = 3;
            this.panelTransaction.Visible = false;
            // 
            // labelCP
            // 
            this.labelCP.AutoSize = true;
            this.labelCP.Location = new System.Drawing.Point(1175, 35);
            this.labelCP.Name = "labelCP";
            this.labelCP.Size = new System.Drawing.Size(236, 26);
            this.labelCP.TabIndex = 24;
            this.labelCP.Text = "Выберите поставщика:";
            // 
            // labelDate
            // 
            this.labelDate.AutoSize = true;
            this.labelDate.Location = new System.Drawing.Point(1146, 246);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(158, 26);
            this.labelDate.TabIndex = 23;
            this.labelDate.Text = "Дата поставки:";
            // 
            // buttonRemoveInvoice
            // 
            this.buttonRemoveInvoice.Location = new System.Drawing.Point(1111, 334);
            this.buttonRemoveInvoice.Name = "buttonRemoveInvoice";
            this.buttonRemoveInvoice.Size = new System.Drawing.Size(194, 87);
            this.buttonRemoveInvoice.TabIndex = 21;
            this.buttonRemoveInvoice.Text = "Сбросить введенные данные";
            this.buttonRemoveInvoice.UseVisualStyleBackColor = true;
            this.buttonRemoveInvoice.Click += new System.EventHandler(this.buttonRemoveInvoice_Click);
            // 
            // buttonSaveTransaction
            // 
            this.buttonSaveTransaction.Location = new System.Drawing.Point(1311, 336);
            this.buttonSaveTransaction.Name = "buttonSaveTransaction";
            this.buttonSaveTransaction.Size = new System.Drawing.Size(190, 86);
            this.buttonSaveTransaction.TabIndex = 20;
            this.buttonSaveTransaction.Text = "Сохранить";
            this.buttonSaveTransaction.UseVisualStyleBackColor = true;
            this.buttonSaveTransaction.Click += new System.EventHandler(this.buttonSaveTransaction_Click);
            // 
            // buttonAddNewCp
            // 
            this.buttonAddNewCp.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonAddNewCp.Location = new System.Drawing.Point(1174, 131);
            this.buttonAddNewCp.Name = "buttonAddNewCp";
            this.buttonAddNewCp.Size = new System.Drawing.Size(237, 70);
            this.buttonAddNewCp.TabIndex = 5;
            this.buttonAddNewCp.Text = "Добавить нового поставщика";
            this.buttonAddNewCp.UseVisualStyleBackColor = true;
            this.buttonAddNewCp.Click += new System.EventHandler(this.buttonAddNewCp_Click);
            // 
            // dateTimTransaction
            // 
            this.dateTimTransaction.CustomFormat = "";
            this.dateTimTransaction.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimTransaction.Location = new System.Drawing.Point(1342, 240);
            this.dateTimTransaction.Name = "dateTimTransaction";
            this.dateTimTransaction.Size = new System.Drawing.Size(127, 34);
            this.dateTimTransaction.TabIndex = 15;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(30, 307);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(0, 26);
            this.label17.TabIndex = 5;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(1227, 201);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(0, 26);
            this.label16.TabIndex = 3;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(1169, 35);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(0, 26);
            this.label15.TabIndex = 1;
            // 
            // comboBoxCounterpartyTransaction
            // 
            this.comboBoxCounterpartyTransaction.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCounterpartyTransaction.FormattingEnabled = true;
            this.comboBoxCounterpartyTransaction.Location = new System.Drawing.Point(1174, 79);
            this.comboBoxCounterpartyTransaction.Name = "comboBoxCounterpartyTransaction";
            this.comboBoxCounterpartyTransaction.Size = new System.Drawing.Size(237, 34);
            this.comboBoxCounterpartyTransaction.TabIndex = 0;
            // 
            // groupBoxCP
            // 
            this.groupBoxCP.Controls.Add(this.textBoxCountryCP);
            this.groupBoxCP.Controls.Add(this.maskedTextBoxPhone);
            this.groupBoxCP.Controls.Add(this.button2);
            this.groupBoxCP.Controls.Add(this.button1);
            this.groupBoxCP.Controls.Add(this.textBoxFirmNameCP);
            this.groupBoxCP.Controls.Add(this.label4);
            this.groupBoxCP.Controls.Add(this.label32);
            this.groupBoxCP.Controls.Add(this.textBoxINNCP);
            this.groupBoxCP.Controls.Add(this.label14);
            this.groupBoxCP.Controls.Add(this.label7);
            this.groupBoxCP.Controls.Add(this.textBoxFullName);
            this.groupBoxCP.Controls.Add(this.textBoxBankAccCP);
            this.groupBoxCP.Controls.Add(this.label13);
            this.groupBoxCP.Controls.Add(this.label8);
            this.groupBoxCP.Controls.Add(this.textBoxAddress);
            this.groupBoxCP.Controls.Add(this.textBoxBankNameCP);
            this.groupBoxCP.Controls.Add(this.label12);
            this.groupBoxCP.Controls.Add(this.label10);
            this.groupBoxCP.Controls.Add(this.label11);
            this.groupBoxCP.Controls.Add(this.textBoxEmailCP);
            this.groupBoxCP.Location = new System.Drawing.Point(0, 3);
            this.groupBoxCP.Name = "groupBoxCP";
            this.groupBoxCP.Size = new System.Drawing.Size(1108, 418);
            this.groupBoxCP.TabIndex = 30;
            this.groupBoxCP.TabStop = false;
            this.groupBoxCP.Text = "Данные Контрагент";
            this.groupBoxCP.Visible = false;
            // 
            // textBoxCountryCP
            // 
            this.textBoxCountryCP.Location = new System.Drawing.Point(353, 135);
            this.textBoxCountryCP.Name = "textBoxCountryCP";
            this.textBoxCountryCP.Size = new System.Drawing.Size(187, 34);
            this.textBoxCountryCP.TabIndex = 21;
            // 
            // maskedTextBoxPhone
            // 
            this.maskedTextBoxPhone.Location = new System.Drawing.Point(295, 325);
            this.maskedTextBoxPhone.Mask = "+0000-(999)-0000-0000";
            this.maskedTextBoxPhone.Name = "maskedTextBoxPhone";
            this.maskedTextBoxPhone.Size = new System.Drawing.Size(245, 34);
            this.maskedTextBoxPhone.TabIndex = 20;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(823, 325);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(230, 89);
            this.button2.TabIndex = 0;
            this.button2.Text = "Сохранить";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button6_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(580, 325);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(230, 89);
            this.button1.TabIndex = 19;
            this.button1.Text = "Прекратить";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button5_Click);
            // 
            // textBoxFirmNameCP
            // 
            this.textBoxFirmNameCP.Location = new System.Drawing.Point(353, 65);
            this.textBoxFirmNameCP.Name = "textBoxFirmNameCP";
            this.textBoxFirmNameCP.Size = new System.Drawing.Size(187, 34);
            this.textBoxFirmNameCP.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(580, 265);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(223, 26);
            this.label4.TabIndex = 18;
            this.label4.Text = "Введите ИНН фирмы:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(55, 68);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(264, 26);
            this.label32.TabIndex = 2;
            this.label32.Text = "Введите название фирмы:";
            // 
            // textBoxINNCP
            // 
            this.textBoxINNCP.Location = new System.Drawing.Point(827, 259);
            this.textBoxINNCP.Name = "textBoxINNCP";
            this.textBoxINNCP.Size = new System.Drawing.Size(226, 34);
            this.textBoxINNCP.TabIndex = 17;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(55, 138);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(243, 26);
            this.label14.TabIndex = 4;
            this.label14.Text = "Введите страну фирмы:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(580, 205);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(222, 26);
            this.label7.TabIndex = 16;
            this.label7.Text = "Введите номер счета:";
            // 
            // textBoxFullName
            // 
            this.textBoxFullName.Location = new System.Drawing.Point(353, 204);
            this.textBoxFullName.Name = "textBoxFullName";
            this.textBoxFullName.Size = new System.Drawing.Size(187, 34);
            this.textBoxFullName.TabIndex = 5;
            // 
            // textBoxBankAccCP
            // 
            this.textBoxBankAccCP.Location = new System.Drawing.Point(827, 199);
            this.textBoxBankAccCP.Name = "textBoxBankAccCP";
            this.textBoxBankAccCP.Size = new System.Drawing.Size(226, 34);
            this.textBoxBankAccCP.TabIndex = 15;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(55, 207);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(292, 26);
            this.label13.TabIndex = 6;
            this.label13.Text = "Введите ФИО руководителя:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(580, 136);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(250, 26);
            this.label8.TabIndex = 14;
            this.label8.Text = "Введите название банка:";
            // 
            // textBoxAddress
            // 
            this.textBoxAddress.Location = new System.Drawing.Point(353, 264);
            this.textBoxAddress.Name = "textBoxAddress";
            this.textBoxAddress.Size = new System.Drawing.Size(187, 34);
            this.textBoxAddress.TabIndex = 7;
            // 
            // textBoxBankNameCP
            // 
            this.textBoxBankNameCP.Location = new System.Drawing.Point(827, 130);
            this.textBoxBankNameCP.Name = "textBoxBankNameCP";
            this.textBoxBankNameCP.Size = new System.Drawing.Size(226, 34);
            this.textBoxBankNameCP.TabIndex = 13;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(55, 267);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(297, 26);
            this.label12.TabIndex = 8;
            this.label12.Text = "Введите юридический адрес:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(580, 66);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(164, 26);
            this.label10.TabIndex = 12;
            this.label10.Text = "Введите E-mail:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(55, 325);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(183, 26);
            this.label11.TabIndex = 10;
            this.label11.Text = "Введите телефон:";
            // 
            // textBoxEmailCP
            // 
            this.textBoxEmailCP.Location = new System.Drawing.Point(827, 60);
            this.textBoxEmailCP.Name = "textBoxEmailCP";
            this.textBoxEmailCP.Size = new System.Drawing.Size(226, 34);
            this.textBoxEmailCP.TabIndex = 11;
            // 
            // groupBoxInvoice
            // 
            this.groupBoxInvoice.BackColor = System.Drawing.Color.White;
            this.groupBoxInvoice.Controls.Add(this.gridReceivedProducts);
            this.groupBoxInvoice.Controls.Add(this.label2);
            this.groupBoxInvoice.Controls.Add(this.comboBoxUnitInvoice);
            this.groupBoxInvoice.Controls.Add(this.textBoxManufactInvoice);
            this.groupBoxInvoice.Controls.Add(this.buttonBarcodeInvoice);
            this.groupBoxInvoice.Controls.Add(this.label40);
            this.groupBoxInvoice.Controls.Add(this.textBoxPriceInvoice);
            this.groupBoxInvoice.Controls.Add(this.buttonNextProduct);
            this.groupBoxInvoice.Controls.Add(this.pictureBox1);
            this.groupBoxInvoice.Controls.Add(this.buttonPhotoInvoice);
            this.groupBoxInvoice.Controls.Add(this.textBoxCountInvoice);
            this.groupBoxInvoice.Controls.Add(this.textBoxNameProductInvoice);
            this.groupBoxInvoice.Controls.Add(this.label36);
            this.groupBoxInvoice.Controls.Add(this.textBoxShelfLifeINvoice);
            this.groupBoxInvoice.Controls.Add(this.pictureBox2);
            this.groupBoxInvoice.Controls.Add(this.buttonDeleteProductList);
            this.groupBoxInvoice.Controls.Add(this.label38);
            this.groupBoxInvoice.Controls.Add(this.label34);
            this.groupBoxInvoice.Controls.Add(this.comboBoxGroupInvoice);
            this.groupBoxInvoice.Controls.Add(this.label41);
            this.groupBoxInvoice.Controls.Add(this.label39);
            this.groupBoxInvoice.Controls.Add(this.label37);
            this.groupBoxInvoice.ForeColor = System.Drawing.SystemColors.ControlText;
            this.groupBoxInvoice.Location = new System.Drawing.Point(21, 33);
            this.groupBoxInvoice.Name = "groupBoxInvoice";
            this.groupBoxInvoice.Size = new System.Drawing.Size(1087, 434);
            this.groupBoxInvoice.TabIndex = 47;
            this.groupBoxInvoice.TabStop = false;
            this.groupBoxInvoice.Text = "Товар №1";
            this.groupBoxInvoice.Visible = false;
            // 
            // gridReceivedProducts
            // 
            this.gridReceivedProducts.AllowUserToAddRows = false;
            this.gridReceivedProducts.AllowUserToDeleteRows = false;
            this.gridReceivedProducts.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gridReceivedProducts.BackgroundColor = System.Drawing.SystemColors.ControlDark;
            this.gridReceivedProducts.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.gridReceivedProducts.ColumnHeadersHeight = 60;
            this.gridReceivedProducts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.gridReceivedProducts.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn7});
            this.gridReceivedProducts.GridColor = System.Drawing.SystemColors.ControlDarkDark;
            this.gridReceivedProducts.Location = new System.Drawing.Point(750, 70);
            this.gridReceivedProducts.Name = "gridReceivedProducts";
            this.gridReceivedProducts.ReadOnly = true;
            this.gridReceivedProducts.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.gridReceivedProducts.RowHeadersVisible = false;
            this.gridReceivedProducts.RowHeadersWidth = 40;
            this.gridReceivedProducts.RowTemplate.Height = 24;
            this.gridReceivedProducts.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.gridReceivedProducts.Size = new System.Drawing.Size(337, 189);
            this.gridReceivedProducts.TabIndex = 48;
            this.gridReceivedProducts.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridReceivedProducts_CellClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.FillWeight = 160.4278F;
            this.dataGridViewTextBoxColumn1.HeaderText = "Название товара";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 150;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.FillWeight = 39.57219F;
            this.dataGridViewTextBoxColumn7.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn7.MinimumWidth = 150;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(816, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(193, 26);
            this.label2.TabIndex = 47;
            this.label2.Text = "Товары в поставке";
            // 
            // comboBoxUnitInvoice
            // 
            this.comboBoxUnitInvoice.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxUnitInvoice.FormattingEnabled = true;
            this.comboBoxUnitInvoice.Items.AddRange(new object[] {
            "",
            "Килограмм",
            "Штука",
            "Упаковка",
            "Литр",
            "Грамм",
            "Миллилитр",
            "Коробка",
            "Бутылка",
            "Банка",
            "пакетик"});
            this.comboBoxUnitInvoice.Location = new System.Drawing.Point(295, 239);
            this.comboBoxUnitInvoice.Name = "comboBoxUnitInvoice";
            this.comboBoxUnitInvoice.Size = new System.Drawing.Size(147, 34);
            this.comboBoxUnitInvoice.TabIndex = 46;
            // 
            // textBoxManufactInvoice
            // 
            this.textBoxManufactInvoice.Location = new System.Drawing.Point(294, 184);
            this.textBoxManufactInvoice.Name = "textBoxManufactInvoice";
            this.textBoxManufactInvoice.Size = new System.Drawing.Size(148, 34);
            this.textBoxManufactInvoice.TabIndex = 30;
            // 
            // buttonBarcodeInvoice
            // 
            this.buttonBarcodeInvoice.Location = new System.Drawing.Point(465, 33);
            this.buttonBarcodeInvoice.Name = "buttonBarcodeInvoice";
            this.buttonBarcodeInvoice.Size = new System.Drawing.Size(261, 51);
            this.buttonBarcodeInvoice.TabIndex = 42;
            this.buttonBarcodeInvoice.Text = "Установить Штрих-код";
            this.buttonBarcodeInvoice.UseVisualStyleBackColor = true;
            this.buttonBarcodeInvoice.Click += new System.EventHandler(this.buttonBarcodeInvoice_Click);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(59, 139);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(302, 26);
            this.label40.TabIndex = 27;
            this.label40.Text = "Срок хранения (кол-во дней):";
            // 
            // textBoxPriceInvoice
            // 
            this.textBoxPriceInvoice.Location = new System.Drawing.Point(394, 344);
            this.textBoxPriceInvoice.Name = "textBoxPriceInvoice";
            this.textBoxPriceInvoice.Size = new System.Drawing.Size(48, 34);
            this.textBoxPriceInvoice.TabIndex = 34;
            // 
            // buttonNextProduct
            // 
            this.buttonNextProduct.Location = new System.Drawing.Point(922, 297);
            this.buttonNextProduct.Name = "buttonNextProduct";
            this.buttonNextProduct.Size = new System.Drawing.Size(165, 89);
            this.buttonNextProduct.TabIndex = 40;
            this.buttonNextProduct.Text = "Подтвердить товар";
            this.buttonNextProduct.UseVisualStyleBackColor = true;
            this.buttonNextProduct.Click += new System.EventHandler(this.buttonNextProduct_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(482, 104);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(215, 81);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 45;
            this.pictureBox1.TabStop = false;
            // 
            // buttonPhotoInvoice
            // 
            this.buttonPhotoInvoice.Location = new System.Drawing.Point(465, 208);
            this.buttonPhotoInvoice.Name = "buttonPhotoInvoice";
            this.buttonPhotoInvoice.Size = new System.Drawing.Size(261, 51);
            this.buttonPhotoInvoice.TabIndex = 39;
            this.buttonPhotoInvoice.Text = "Установить фото товара";
            this.buttonPhotoInvoice.UseVisualStyleBackColor = true;
            this.buttonPhotoInvoice.Click += new System.EventHandler(this.buttonPhotoInvoice_Click);
            // 
            // textBoxCountInvoice
            // 
            this.textBoxCountInvoice.Location = new System.Drawing.Point(394, 290);
            this.textBoxCountInvoice.Name = "textBoxCountInvoice";
            this.textBoxCountInvoice.Size = new System.Drawing.Size(48, 34);
            this.textBoxCountInvoice.TabIndex = 32;
            // 
            // textBoxNameProductInvoice
            // 
            this.textBoxNameProductInvoice.Location = new System.Drawing.Point(294, 33);
            this.textBoxNameProductInvoice.Name = "textBoxNameProductInvoice";
            this.textBoxNameProductInvoice.Size = new System.Drawing.Size(148, 34);
            this.textBoxNameProductInvoice.TabIndex = 26;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(59, 86);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(158, 26);
            this.label36.TabIndex = 35;
            this.label36.Text = "Группа товара:";
            // 
            // textBoxShelfLifeINvoice
            // 
            this.textBoxShelfLifeINvoice.ImeMode = System.Windows.Forms.ImeMode.On;
            this.textBoxShelfLifeINvoice.Location = new System.Drawing.Point(394, 136);
            this.textBoxShelfLifeINvoice.Name = "textBoxShelfLifeINvoice";
            this.textBoxShelfLifeINvoice.Size = new System.Drawing.Size(48, 34);
            this.textBoxShelfLifeINvoice.TabIndex = 28;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(482, 275);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(215, 81);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 44;
            this.pictureBox2.TabStop = false;
            // 
            // buttonDeleteProductList
            // 
            this.buttonDeleteProductList.Location = new System.Drawing.Point(750, 298);
            this.buttonDeleteProductList.Name = "buttonDeleteProductList";
            this.buttonDeleteProductList.Size = new System.Drawing.Size(165, 87);
            this.buttonDeleteProductList.TabIndex = 41;
            this.buttonDeleteProductList.Text = "Удалить товар";
            this.buttonDeleteProductList.UseVisualStyleBackColor = true;
            this.buttonDeleteProductList.Visible = false;
            this.buttonDeleteProductList.Click += new System.EventHandler(this.buttonDeleteProductInvoice_Click);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(59, 296);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(133, 26);
            this.label38.TabIndex = 31;
            this.label38.Text = "Количество:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(59, 246);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(185, 26);
            this.label34.TabIndex = 38;
            this.label34.Text = "Учетная единица:";
            // 
            // comboBoxGroupInvoice
            // 
            this.comboBoxGroupInvoice.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxGroupInvoice.FormattingEnabled = true;
            this.comboBoxGroupInvoice.Items.AddRange(new object[] {
            "",
            "Овощи",
            "Фрукты",
            "Кондитерские изделия",
            "Мясные изделия",
            "Молочные продукты",
            "Хлебобулочные изделия",
            "Напитки",
            "Консервы",
            "Морепродукты",
            "Бакалея",
            "Замороженные продукты",
            "Специи",
            "масла и жиры",
            "Сладости",
            "Полуфабрикаты"});
            this.comboBoxGroupInvoice.Location = new System.Drawing.Point(294, 83);
            this.comboBoxGroupInvoice.Name = "comboBoxGroupInvoice";
            this.comboBoxGroupInvoice.Size = new System.Drawing.Size(148, 34);
            this.comboBoxGroupInvoice.TabIndex = 43;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(59, 36);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(178, 26);
            this.label41.TabIndex = 25;
            this.label41.Text = "Название товара:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(59, 192);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(154, 26);
            this.label39.TabIndex = 29;
            this.label39.Text = "Изготовитель: ";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(59, 347);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(292, 26);
            this.label37.TabIndex = 33;
            this.label37.Text = "Закупочная цена за единицу:";
            // 
            // panelOrder
            // 
            this.panelOrder.Controls.Add(this.label50);
            this.panelOrder.Controls.Add(this.textBox6);
            this.panelOrder.Controls.Add(this.panel1);
            this.panelOrder.Controls.Add(this.label45);
            this.panelOrder.Controls.Add(this.dataGridView2);
            this.panelOrder.Controls.Add(this.dataGridView1);
            this.panelOrder.Controls.Add(this.label3);
            this.panelOrder.Controls.Add(this.pictureBox3);
            this.panelOrder.Controls.Add(this.pictureBox4);
            this.panelOrder.Controls.Add(this.buttonCompleteOrder);
            this.panelOrder.Controls.Add(this.buttonRemoveProductOrder);
            this.panelOrder.Location = new System.Drawing.Point(0, 0);
            this.panelOrder.Name = "panelOrder";
            this.panelOrder.Size = new System.Drawing.Size(1108, 439);
            this.panelOrder.TabIndex = 10;
            this.panelOrder.TabStop = false;
            this.panelOrder.Visible = false;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label50.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label50.Location = new System.Drawing.Point(697, 277);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(276, 26);
            this.label50.TabIndex = 80;
            this.label50.Text = "Количество товара в заказ:";
            this.label50.Visible = false;
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox6.Location = new System.Drawing.Point(979, 274);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(112, 34);
            this.textBox6.TabIndex = 79;
            this.textBox6.Visible = false;
            // 
            // panel1
            // 
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel1.Controls.Add(this.label35);
            this.panel1.Controls.Add(this.textBox4);
            this.panel1.Controls.Add(this.label47);
            this.panel1.Controls.Add(this.label49);
            this.panel1.Controls.Add(this.label46);
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.comboBox2);
            this.panel1.Controls.Add(this.label48);
            this.panel1.Controls.Add(this.label44);
            this.panel1.Controls.Add(this.textBox5);
            this.panel1.Controls.Add(this.label43);
            this.panel1.Controls.Add(this.label42);
            this.panel1.Controls.Add(this.dateTimePicker1);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Enabled = false;
            this.panel1.Location = new System.Drawing.Point(304, 16);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(375, 405);
            this.panel1.TabIndex = 78;
            this.panel1.Visible = false;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label35.Location = new System.Drawing.Point(20, 221);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(263, 22);
            this.label35.TabIndex = 51;
            this.label35.Text = "Срок хранения (кол-во дней):";
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox4.Location = new System.Drawing.Point(184, 17);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(169, 30);
            this.textBox4.TabIndex = 77;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label47.Location = new System.Drawing.Point(20, 376);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(257, 22);
            this.label47.TabIndex = 57;
            this.label47.Text = "Закупочная цена за единицу:";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label49.Location = new System.Drawing.Point(20, 71);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(115, 22);
            this.label49.TabIndex = 76;
            this.label49.Text = "Количество:";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label46.Location = new System.Drawing.Point(20, 274);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(137, 22);
            this.label46.TabIndex = 53;
            this.label46.Text = "Изготовитель: ";
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox3.Location = new System.Drawing.Point(184, 62);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(169, 30);
            this.textBox3.TabIndex = 75;
            // 
            // comboBox2
            // 
            this.comboBox2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "",
            "Овощи",
            "Фрукты",
            "Кондитерские изделия",
            "Мясные изделия",
            "Молочные продукты",
            "Хлебобулочные изделия",
            "Напитки",
            "Консервы",
            "Морепродукты",
            "Бакалея",
            "Замороженные продукты",
            "Специи",
            "масла и жиры",
            "Сладости",
            "Полуфабрикаты"});
            this.comboBox2.Location = new System.Drawing.Point(182, 163);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(171, 30);
            this.comboBox2.TabIndex = 64;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label48.Location = new System.Drawing.Point(20, 20);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(157, 22);
            this.label48.TabIndex = 74;
            this.label48.Text = "Название товара:";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label44.Location = new System.Drawing.Point(20, 328);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(164, 22);
            this.label44.TabIndex = 60;
            this.label44.Text = "Учетная единица:";
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox5.ImeMode = System.Windows.Forms.ImeMode.On;
            this.textBox5.Location = new System.Drawing.Point(299, 216);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(54, 30);
            this.textBox5.TabIndex = 52;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label43.Location = new System.Drawing.Point(20, 118);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(139, 22);
            this.label43.TabIndex = 72;
            this.label43.Text = "Дата поставки:";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label42.Location = new System.Drawing.Point(20, 168);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(138, 22);
            this.label42.TabIndex = 59;
            this.label42.Text = "Группа товара:";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "";
            this.dateTimePicker1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(182, 110);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(171, 30);
            this.dateTimePicker1.TabIndex = 71;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox2.Location = new System.Drawing.Point(281, 371);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(72, 30);
            this.textBox2.TabIndex = 58;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox1.Location = new System.Drawing.Point(183, 264);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(170, 30);
            this.textBox1.TabIndex = 54;
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "",
            "Килограмм",
            "Штука",
            "Упаковка",
            "Литр",
            "Грамм",
            "Миллилитр",
            "Коробка",
            "Бутылка",
            "Банка",
            "пакетик"});
            this.comboBox1.Location = new System.Drawing.Point(184, 319);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(169, 30);
            this.comboBox1.TabIndex = 67;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(8, 35);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(281, 26);
            this.label45.TabIndex = 73;
            this.label45.Text = "Выберите товары со склада";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.ControlDark;
            this.dataGridView2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dataGridView2.ColumnHeadersHeight = 60;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn4,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7,
            this.dataGridViewTextBoxColumn5,
            this.Column8,
            this.Column9,
            this.Column10});
            this.dataGridView2.GridColor = System.Drawing.SystemColors.ControlDarkDark;
            this.dataGridView2.Location = new System.Drawing.Point(8, 76);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.RowHeadersWidth = 40;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(281, 235);
            this.dataGridView2.TabIndex = 70;
            this.dataGridView2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellClick);
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.FillWeight = 160.4278F;
            this.dataGridViewTextBoxColumn4.HeaderText = "Название товара";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 170;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn4.Width = 183;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Дата поставки";
            this.Column3.MinimumWidth = 110;
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column3.Width = 165;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Группа товара";
            this.Column4.MinimumWidth = 110;
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column4.Width = 165;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Срок хранения";
            this.Column5.MinimumWidth = 120;
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column5.Width = 171;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Изготовитель";
            this.Column6.MinimumWidth = 150;
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            this.Column6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column6.Width = 171;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "Учетная единица";
            this.Column7.MinimumWidth = 120;
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            this.Column7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column7.Width = 190;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.FillWeight = 39.57219F;
            this.dataGridViewTextBoxColumn5.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 140;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn5.Width = 156;
            // 
            // Column8
            // 
            this.Column8.HeaderText = "Закупочная цена за единицу";
            this.Column8.MinimumWidth = 180;
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            this.Column8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column8.Width = 213;
            // 
            // Column9
            // 
            this.Column9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Column9.HeaderText = "Штрих-код товара";
            this.Column9.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Zoom;
            this.Column9.MinimumWidth = 140;
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            this.Column9.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Column9.Width = 140;
            // 
            // Column10
            // 
            this.Column10.HeaderText = "Фото товара";
            this.Column10.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Zoom;
            this.Column10.MinimumWidth = 140;
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            this.Column10.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Column10.Width = 150;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlDark;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dataGridView1.ColumnHeadersHeight = 60;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.Column2});
            this.dataGridView1.GridColor = System.Drawing.SystemColors.ControlDarkDark;
            this.dataGridView1.Location = new System.Drawing.Point(695, 76);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 40;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView1.Size = new System.Drawing.Size(396, 165);
            this.dataGridView1.TabIndex = 69;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick_1);
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.FillWeight = 160.4278F;
            this.dataGridViewTextBoxColumn2.HeaderText = "Название товара";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 110;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.FillWeight = 39.57219F;
            this.dataGridViewTextBoxColumn3.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 130;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Отпускная цена";
            this.Column2.MinimumWidth = 175;
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(818, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(166, 26);
            this.label3.TabIndex = 68;
            this.label3.Text = "Товары в заказе";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(154, 342);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(135, 76);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 66;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Visible = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Location = new System.Drawing.Point(4, 342);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(134, 76);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 65;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Visible = false;
            // 
            // buttonCompleteOrder
            // 
            this.buttonCompleteOrder.Location = new System.Drawing.Point(895, 334);
            this.buttonCompleteOrder.Name = "buttonCompleteOrder";
            this.buttonCompleteOrder.Size = new System.Drawing.Size(196, 87);
            this.buttonCompleteOrder.TabIndex = 3;
            this.buttonCompleteOrder.Text = "Подтвердить товар";
            this.buttonCompleteOrder.UseVisualStyleBackColor = true;
            this.buttonCompleteOrder.Visible = false;
            this.buttonCompleteOrder.Click += new System.EventHandler(this.buttonCompleteOrder_Click);
            // 
            // buttonRemoveProductOrder
            // 
            this.buttonRemoveProductOrder.Location = new System.Drawing.Point(695, 335);
            this.buttonRemoveProductOrder.Name = "buttonRemoveProductOrder";
            this.buttonRemoveProductOrder.Size = new System.Drawing.Size(196, 86);
            this.buttonRemoveProductOrder.TabIndex = 2;
            this.buttonRemoveProductOrder.Text = "Удалить";
            this.buttonRemoveProductOrder.UseVisualStyleBackColor = true;
            this.buttonRemoveProductOrder.Visible = false;
            this.buttonRemoveProductOrder.Click += new System.EventHandler(this.buttonRemoveProductOrder_Click);
            // 
            // buttonLeaveTransaction
            // 
            this.buttonLeaveTransaction.Location = new System.Drawing.Point(1111, 5);
            this.buttonLeaveTransaction.Name = "buttonLeaveTransaction";
            this.buttonLeaveTransaction.Size = new System.Drawing.Size(385, 138);
            this.buttonLeaveTransaction.TabIndex = 31;
            this.buttonLeaveTransaction.Text = "Оставить операцию";
            this.buttonLeaveTransaction.UseVisualStyleBackColor = true;
            this.buttonLeaveTransaction.Visible = false;
            this.buttonLeaveTransaction.Click += new System.EventHandler(this.buttonLeaveTransaction_Click);
            // 
            // buttondeleteTransaction
            // 
            this.buttondeleteTransaction.Location = new System.Drawing.Point(1111, 149);
            this.buttondeleteTransaction.Name = "buttondeleteTransaction";
            this.buttondeleteTransaction.Size = new System.Drawing.Size(385, 138);
            this.buttondeleteTransaction.TabIndex = 30;
            this.buttondeleteTransaction.Text = "Удалить операцию";
            this.buttondeleteTransaction.UseVisualStyleBackColor = true;
            this.buttondeleteTransaction.Visible = false;
            this.buttondeleteTransaction.Click += new System.EventHandler(this.buttondeleteTransaction_Click);
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.White;
            this.panelMenu.Controls.Add(this.label33);
            this.panelMenu.Controls.Add(this.button5);
            this.panelMenu.Controls.Add(this.button4);
            this.panelMenu.Location = new System.Drawing.Point(1111, 293);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(385, 132);
            this.panelMenu.TabIndex = 27;
            this.panelMenu.Visible = false;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(67, 11);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(246, 26);
            this.label33.TabIndex = 2;
            this.label33.Text = "Выберите вид операции";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(0, 40);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(189, 81);
            this.button5.TabIndex = 1;
            this.button5.Text = "Накладная";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.buttonAddInvoice_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(195, 40);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(190, 81);
            this.button4.TabIndex = 0;
            this.button4.Text = "Заказ";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.buttonAddOrder_Click);
            // 
            // buttonAddTrans
            // 
            this.buttonAddTrans.Location = new System.Drawing.Point(1111, 293);
            this.buttonAddTrans.Name = "buttonAddTrans";
            this.buttonAddTrans.Size = new System.Drawing.Size(385, 121);
            this.buttonAddTrans.TabIndex = 26;
            this.buttonAddTrans.Text = "Добавить операцию";
            this.buttonAddTrans.UseVisualStyleBackColor = true;
            this.buttonAddTrans.Click += new System.EventHandler(this.buttonAddTrans_Click);
            // 
            // GridTrsnsaction
            // 
            this.GridTrsnsaction.AllowUserToAddRows = false;
            this.GridTrsnsaction.AllowUserToDeleteRows = false;
            this.GridTrsnsaction.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.GridTrsnsaction.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.GridTrsnsaction.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.GridTrsnsaction.ColumnHeadersHeight = 90;
            this.GridTrsnsaction.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.GridTrsnsaction.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumType,
            this.ColumnCP,
            this.ColumnDate,
            this.Column1});
            this.GridTrsnsaction.Dock = System.Windows.Forms.DockStyle.Left;
            this.GridTrsnsaction.Location = new System.Drawing.Point(3, 3);
            this.GridTrsnsaction.Name = "GridTrsnsaction";
            this.GridTrsnsaction.ReadOnly = true;
            this.GridTrsnsaction.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.GridTrsnsaction.RowHeadersVisible = false;
            this.GridTrsnsaction.RowHeadersWidth = 51;
            this.GridTrsnsaction.RowTemplate.Height = 24;
            this.GridTrsnsaction.RowTemplate.ReadOnly = true;
            this.GridTrsnsaction.Size = new System.Drawing.Size(1105, 425);
            this.GridTrsnsaction.TabIndex = 29;
            this.GridTrsnsaction.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GridTrsnsaction_CellClick);
            // 
            // ColumType
            // 
            this.ColumType.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ColumType.FillWeight = 1F;
            this.ColumType.HeaderText = "Вид операции";
            this.ColumType.MinimumWidth = 130;
            this.ColumType.Name = "ColumType";
            this.ColumType.ReadOnly = true;
            this.ColumType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ColumType.Width = 130;
            // 
            // ColumnCP
            // 
            this.ColumnCP.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ColumnCP.FillWeight = 10F;
            this.ColumnCP.HeaderText = "Контрагент";
            this.ColumnCP.MinimumWidth = 140;
            this.ColumnCP.Name = "ColumnCP";
            this.ColumnCP.ReadOnly = true;
            this.ColumnCP.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ColumnCP.Width = 140;
            // 
            // ColumnDate
            // 
            this.ColumnDate.HeaderText = "Дата";
            this.ColumnDate.MinimumWidth = 100;
            this.ColumnDate.Name = "ColumnDate";
            this.ColumnDate.ReadOnly = true;
            this.ColumnDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column1.HeaderText = "Список товаров";
            this.Column1.MinimumWidth = 6;
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // tabPageWarehouse
            // 
            this.tabPageWarehouse.BackColor = System.Drawing.Color.Transparent;
            this.tabPageWarehouse.Controls.Add(this.panelProduct);
            this.tabPageWarehouse.Controls.Add(this.buttonAddProduct);
            this.tabPageWarehouse.Controls.Add(this.GridWareHouse);
            this.tabPageWarehouse.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabPageWarehouse.Location = new System.Drawing.Point(4, 64);
            this.tabPageWarehouse.Name = "tabPageWarehouse";
            this.tabPageWarehouse.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageWarehouse.Size = new System.Drawing.Size(1504, 431);
            this.tabPageWarehouse.TabIndex = 0;
            this.tabPageWarehouse.Text = "Склад";
            // 
            // panelProduct
            // 
            this.panelProduct.BackColor = System.Drawing.Color.White;
            this.panelProduct.Controls.Add(this.buttonDeleteProduct);
            this.panelProduct.Controls.Add(this.labelTitleProduct);
            this.panelProduct.Controls.Add(this.comboBoxUnit);
            this.panelProduct.Controls.Add(this.pictureBoxBarcode);
            this.panelProduct.Controls.Add(this.pictureBoxPhote);
            this.panelProduct.Controls.Add(this.comboBoxProductGroup);
            this.panelProduct.Controls.Add(this.buttonBarcode);
            this.panelProduct.Controls.Add(this.buttonRemoveProduct);
            this.panelProduct.Controls.Add(this.buttonSaveProduct);
            this.panelProduct.Controls.Add(this.btnPhotoPath);
            this.panelProduct.Controls.Add(this.label1);
            this.panelProduct.Controls.Add(this.dateTimePickerDeliveryDate);
            this.panelProduct.Controls.Add(this.labelDeliveryDate);
            this.panelProduct.Controls.Add(this.labelgroup);
            this.panelProduct.Controls.Add(this.textBoxPurchasePrice);
            this.panelProduct.Controls.Add(this.label6);
            this.panelProduct.Controls.Add(this.textBoxCountProduct);
            this.panelProduct.Controls.Add(this.label5);
            this.panelProduct.Controls.Add(this.textBoxManufactory);
            this.panelProduct.Controls.Add(this.labelManufuc);
            this.panelProduct.Controls.Add(this.textBoxShelfLife);
            this.panelProduct.Controls.Add(this.labelDelDate);
            this.panelProduct.Controls.Add(this.textBoxNameProduct);
            this.panelProduct.Controls.Add(this.labelNamePr);
            this.panelProduct.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.panelProduct.Location = new System.Drawing.Point(0, 0);
            this.panelProduct.Name = "panelProduct";
            this.panelProduct.Size = new System.Drawing.Size(1508, 484);
            this.panelProduct.TabIndex = 1;
            this.panelProduct.Visible = false;
            // 
            // buttonDeleteProduct
            // 
            this.buttonDeleteProduct.Location = new System.Drawing.Point(1178, 166);
            this.buttonDeleteProduct.Name = "buttonDeleteProduct";
            this.buttonDeleteProduct.Size = new System.Drawing.Size(203, 112);
            this.buttonDeleteProduct.TabIndex = 26;
            this.buttonDeleteProduct.Text = "Удалить";
            this.buttonDeleteProduct.UseVisualStyleBackColor = true;
            this.buttonDeleteProduct.Visible = false;
            this.buttonDeleteProduct.Click += new System.EventHandler(this.buttonDeleteProduct_Click);
            // 
            // labelTitleProduct
            // 
            this.labelTitleProduct.AutoSize = true;
            this.labelTitleProduct.Location = new System.Drawing.Point(614, 21);
            this.labelTitleProduct.Name = "labelTitleProduct";
            this.labelTitleProduct.Size = new System.Drawing.Size(199, 26);
            this.labelTitleProduct.TabIndex = 25;
            this.labelTitleProduct.Text = "Добавление товара";
            // 
            // comboBoxUnit
            // 
            this.comboBoxUnit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxUnit.FormattingEnabled = true;
            this.comboBoxUnit.Items.AddRange(new object[] {
            "",
            "Килограмм",
            "Штука",
            "Упаковка",
            "Литр",
            "Грамм",
            "Миллилитр",
            "Коробка",
            "Бутылка",
            "Банка",
            "пакетик"});
            this.comboBoxUnit.Location = new System.Drawing.Point(316, 333);
            this.comboBoxUnit.Name = "comboBoxUnit";
            this.comboBoxUnit.Size = new System.Drawing.Size(194, 34);
            this.comboBoxUnit.TabIndex = 24;
            // 
            // pictureBoxBarcode
            // 
            this.pictureBoxBarcode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBoxBarcode.Location = new System.Drawing.Point(918, 176);
            this.pictureBoxBarcode.Name = "pictureBoxBarcode";
            this.pictureBoxBarcode.Size = new System.Drawing.Size(132, 73);
            this.pictureBoxBarcode.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxBarcode.TabIndex = 23;
            this.pictureBoxBarcode.TabStop = false;
            // 
            // pictureBoxPhote
            // 
            this.pictureBoxPhote.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBoxPhote.Location = new System.Drawing.Point(918, 275);
            this.pictureBoxPhote.Name = "pictureBoxPhote";
            this.pictureBoxPhote.Size = new System.Drawing.Size(132, 68);
            this.pictureBoxPhote.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxPhote.TabIndex = 22;
            this.pictureBoxPhote.TabStop = false;
            // 
            // comboBoxProductGroup
            // 
            this.comboBoxProductGroup.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxProductGroup.FormattingEnabled = true;
            this.comboBoxProductGroup.ImeMode = System.Windows.Forms.ImeMode.Close;
            this.comboBoxProductGroup.Items.AddRange(new object[] {
            "",
            "Овощи",
            "Фрукты",
            "Кондитерские изделия",
            "Мясные изделия",
            "Молочные продукты",
            "Хлебобулочные изделия",
            "Напитки",
            "Консервы",
            "Морепродукты",
            "Бакалея",
            "Замороженные продукты",
            "Специи",
            "масла и жиры",
            "Сладости",
            "Полуфабрикаты"});
            this.comboBoxProductGroup.Location = new System.Drawing.Point(315, 116);
            this.comboBoxProductGroup.Name = "comboBoxProductGroup";
            this.comboBoxProductGroup.Size = new System.Drawing.Size(195, 34);
            this.comboBoxProductGroup.TabIndex = 21;
            // 
            // buttonBarcode
            // 
            this.buttonBarcode.Location = new System.Drawing.Point(566, 188);
            this.buttonBarcode.Name = "buttonBarcode";
            this.buttonBarcode.Size = new System.Drawing.Size(323, 51);
            this.buttonBarcode.TabIndex = 20;
            this.buttonBarcode.Text = "Установить Штрих-код";
            this.buttonBarcode.UseVisualStyleBackColor = true;
            this.buttonBarcode.Click += new System.EventHandler(this.button4_Click);
            // 
            // buttonRemoveProduct
            // 
            this.buttonRemoveProduct.Location = new System.Drawing.Point(1178, 166);
            this.buttonRemoveProduct.Name = "buttonRemoveProduct";
            this.buttonRemoveProduct.Size = new System.Drawing.Size(203, 112);
            this.buttonRemoveProduct.TabIndex = 19;
            this.buttonRemoveProduct.Text = "Сбросить веденные данные";
            this.buttonRemoveProduct.UseVisualStyleBackColor = true;
            this.buttonRemoveProduct.Click += new System.EventHandler(this.buttonRemoveProduct_Click);
            // 
            // buttonSaveProduct
            // 
            this.buttonSaveProduct.Location = new System.Drawing.Point(1178, 41);
            this.buttonSaveProduct.Name = "buttonSaveProduct";
            this.buttonSaveProduct.Size = new System.Drawing.Size(203, 114);
            this.buttonSaveProduct.TabIndex = 18;
            this.buttonSaveProduct.Text = "Сохранить";
            this.buttonSaveProduct.UseVisualStyleBackColor = true;
            this.buttonSaveProduct.Click += new System.EventHandler(this.buttonSaveProduct_Click);
            // 
            // btnPhotoPath
            // 
            this.btnPhotoPath.Location = new System.Drawing.Point(566, 281);
            this.btnPhotoPath.Name = "btnPhotoPath";
            this.btnPhotoPath.Size = new System.Drawing.Size(323, 51);
            this.btnPhotoPath.TabIndex = 17;
            this.btnPhotoPath.Text = "Установить фото товара";
            this.btnPhotoPath.UseVisualStyleBackColor = true;
            this.btnPhotoPath.Click += new System.EventHandler(this.btnPhotoPath_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 336);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(185, 26);
            this.label1.TabIndex = 15;
            this.label1.Text = "Учетная единица:";
            // 
            // dateTimePickerDeliveryDate
            // 
            this.dateTimePickerDeliveryDate.CustomFormat = "";
            this.dateTimePickerDeliveryDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerDeliveryDate.Location = new System.Drawing.Point(315, 175);
            this.dateTimePickerDeliveryDate.Name = "dateTimePickerDeliveryDate";
            this.dateTimePickerDeliveryDate.Size = new System.Drawing.Size(195, 34);
            this.dateTimePickerDeliveryDate.TabIndex = 14;
            // 
            // labelDeliveryDate
            // 
            this.labelDeliveryDate.AutoSize = true;
            this.labelDeliveryDate.Location = new System.Drawing.Point(27, 175);
            this.labelDeliveryDate.Name = "labelDeliveryDate";
            this.labelDeliveryDate.Size = new System.Drawing.Size(158, 26);
            this.labelDeliveryDate.TabIndex = 11;
            this.labelDeliveryDate.Text = "Дата поставки:";
            // 
            // labelgroup
            // 
            this.labelgroup.AutoSize = true;
            this.labelgroup.Location = new System.Drawing.Point(27, 119);
            this.labelgroup.Name = "labelgroup";
            this.labelgroup.Size = new System.Drawing.Size(158, 26);
            this.labelgroup.TabIndex = 10;
            this.labelgroup.Text = "Группа товара:";
            // 
            // textBoxPurchasePrice
            // 
            this.textBoxPurchasePrice.Location = new System.Drawing.Point(940, 116);
            this.textBoxPurchasePrice.Name = "textBoxPurchasePrice";
            this.textBoxPurchasePrice.Size = new System.Drawing.Size(100, 34);
            this.textBoxPurchasePrice.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(561, 119);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(292, 26);
            this.label6.TabIndex = 8;
            this.label6.Text = "Закупочная цена за единицу:";
            // 
            // textBoxCountProduct
            // 
            this.textBoxCountProduct.Location = new System.Drawing.Point(940, 62);
            this.textBoxCountProduct.Name = "textBoxCountProduct";
            this.textBoxCountProduct.Size = new System.Drawing.Size(100, 34);
            this.textBoxCountProduct.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(561, 68);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(133, 26);
            this.label5.TabIndex = 6;
            this.label5.Text = "Количество:";
            // 
            // textBoxManufactory
            // 
            this.textBoxManufactory.Location = new System.Drawing.Point(315, 274);
            this.textBoxManufactory.Name = "textBoxManufactory";
            this.textBoxManufactory.Size = new System.Drawing.Size(195, 34);
            this.textBoxManufactory.TabIndex = 5;
            // 
            // labelManufuc
            // 
            this.labelManufuc.AutoSize = true;
            this.labelManufuc.Location = new System.Drawing.Point(27, 282);
            this.labelManufuc.Name = "labelManufuc";
            this.labelManufuc.Size = new System.Drawing.Size(154, 26);
            this.labelManufuc.TabIndex = 4;
            this.labelManufuc.Text = "Изготовитель: ";
            // 
            // textBoxShelfLife
            // 
            this.textBoxShelfLife.ImeMode = System.Windows.Forms.ImeMode.On;
            this.textBoxShelfLife.Location = new System.Drawing.Point(410, 226);
            this.textBoxShelfLife.Name = "textBoxShelfLife";
            this.textBoxShelfLife.Size = new System.Drawing.Size(100, 34);
            this.textBoxShelfLife.TabIndex = 3;
            // 
            // labelDelDate
            // 
            this.labelDelDate.AutoSize = true;
            this.labelDelDate.Location = new System.Drawing.Point(27, 229);
            this.labelDelDate.Name = "labelDelDate";
            this.labelDelDate.Size = new System.Drawing.Size(302, 26);
            this.labelDelDate.TabIndex = 2;
            this.labelDelDate.Text = "Срок хранения (кол-во дней):";
            // 
            // textBoxNameProduct
            // 
            this.textBoxNameProduct.Location = new System.Drawing.Point(315, 66);
            this.textBoxNameProduct.Name = "textBoxNameProduct";
            this.textBoxNameProduct.Size = new System.Drawing.Size(195, 34);
            this.textBoxNameProduct.TabIndex = 1;
            // 
            // labelNamePr
            // 
            this.labelNamePr.AutoSize = true;
            this.labelNamePr.Location = new System.Drawing.Point(27, 69);
            this.labelNamePr.Name = "labelNamePr";
            this.labelNamePr.Size = new System.Drawing.Size(178, 26);
            this.labelNamePr.TabIndex = 0;
            this.labelNamePr.Text = "Название товара:";
            // 
            // buttonAddProduct
            // 
            this.buttonAddProduct.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonAddProduct.Location = new System.Drawing.Point(619, 347);
            this.buttonAddProduct.Name = "buttonAddProduct";
            this.buttonAddProduct.Size = new System.Drawing.Size(270, 81);
            this.buttonAddProduct.TabIndex = 2;
            this.buttonAddProduct.Text = "Добавить товар";
            this.buttonAddProduct.UseVisualStyleBackColor = true;
            this.buttonAddProduct.Click += new System.EventHandler(this.buttonAddProduct_Click);
            // 
            // GridWareHouse
            // 
            this.GridWareHouse.AllowUserToAddRows = false;
            this.GridWareHouse.AllowUserToDeleteRows = false;
            this.GridWareHouse.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.GridWareHouse.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.GridWareHouse.BackgroundColor = System.Drawing.SystemColors.ControlDark;
            this.GridWareHouse.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.GridWareHouse.ColumnHeadersHeight = 90;
            this.GridWareHouse.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.GridWareHouse.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnProductName,
            this.ColumnProductGroup,
            this.ColumnDeliveryDate,
            this.ColumnShelfLife,
            this.ColumnManufacturer,
            this.ColumnUnit,
            this.ColumnQuantity,
            this.ColumnPurchasePrice,
            this.ColumnBarcode,
            this.ColumnPhotoPath});
            this.GridWareHouse.Dock = System.Windows.Forms.DockStyle.Fill;
            this.GridWareHouse.GridColor = System.Drawing.SystemColors.ControlDarkDark;
            this.GridWareHouse.Location = new System.Drawing.Point(3, 3);
            this.GridWareHouse.Name = "GridWareHouse";
            this.GridWareHouse.ReadOnly = true;
            this.GridWareHouse.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.GridWareHouse.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.GridWareHouse.RowHeadersVisible = false;
            this.GridWareHouse.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.GridWareHouse.RowTemplate.Height = 24;
            this.GridWareHouse.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.GridWareHouse.Size = new System.Drawing.Size(1498, 425);
            this.GridWareHouse.TabIndex = 0;
            this.GridWareHouse.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GridWareHouse_CellClick);
            // 
            // ColumnProductName
            // 
            this.ColumnProductName.HeaderText = "Название товара";
            this.ColumnProductName.MinimumWidth = 6;
            this.ColumnProductName.Name = "ColumnProductName";
            this.ColumnProductName.ReadOnly = true;
            this.ColumnProductName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ColumnProductGroup
            // 
            this.ColumnProductGroup.HeaderText = "Группа товара";
            this.ColumnProductGroup.MinimumWidth = 6;
            this.ColumnProductGroup.Name = "ColumnProductGroup";
            this.ColumnProductGroup.ReadOnly = true;
            this.ColumnProductGroup.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ColumnDeliveryDate
            // 
            this.ColumnDeliveryDate.HeaderText = "Дата поставки";
            this.ColumnDeliveryDate.MinimumWidth = 6;
            this.ColumnDeliveryDate.Name = "ColumnDeliveryDate";
            this.ColumnDeliveryDate.ReadOnly = true;
            this.ColumnDeliveryDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ColumnShelfLife
            // 
            this.ColumnShelfLife.HeaderText = "Срок хранения";
            this.ColumnShelfLife.MinimumWidth = 6;
            this.ColumnShelfLife.Name = "ColumnShelfLife";
            this.ColumnShelfLife.ReadOnly = true;
            this.ColumnShelfLife.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ColumnManufacturer
            // 
            this.ColumnManufacturer.HeaderText = "Изготовитель";
            this.ColumnManufacturer.MinimumWidth = 6;
            this.ColumnManufacturer.Name = "ColumnManufacturer";
            this.ColumnManufacturer.ReadOnly = true;
            this.ColumnManufacturer.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ColumnUnit
            // 
            this.ColumnUnit.HeaderText = "Учетная единица";
            this.ColumnUnit.MinimumWidth = 6;
            this.ColumnUnit.Name = "ColumnUnit";
            this.ColumnUnit.ReadOnly = true;
            this.ColumnUnit.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ColumnQuantity
            // 
            this.ColumnQuantity.HeaderText = "Количество";
            this.ColumnQuantity.MinimumWidth = 6;
            this.ColumnQuantity.Name = "ColumnQuantity";
            this.ColumnQuantity.ReadOnly = true;
            this.ColumnQuantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ColumnPurchasePrice
            // 
            this.ColumnPurchasePrice.HeaderText = "Закупочная цена за единицу";
            this.ColumnPurchasePrice.MinimumWidth = 6;
            this.ColumnPurchasePrice.Name = "ColumnPurchasePrice";
            this.ColumnPurchasePrice.ReadOnly = true;
            this.ColumnPurchasePrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ColumnBarcode
            // 
            this.ColumnBarcode.HeaderText = "Штрих-код товара";
            this.ColumnBarcode.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Zoom;
            this.ColumnBarcode.MinimumWidth = 6;
            this.ColumnBarcode.Name = "ColumnBarcode";
            this.ColumnBarcode.ReadOnly = true;
            // 
            // ColumnPhotoPath
            // 
            this.ColumnPhotoPath.HeaderText = "Фото товара";
            this.ColumnPhotoPath.ImageLayout = System.Windows.Forms.DataGridViewImageCellLayout.Zoom;
            this.ColumnPhotoPath.MinimumWidth = 6;
            this.ColumnPhotoPath.Name = "ColumnPhotoPath";
            this.ColumnPhotoPath.ReadOnly = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPageWarehouse);
            this.tabControl1.Controls.Add(this.tabPageTransaction);
            this.tabControl1.Controls.Add(this.tabPageCounterparty);
            this.tabControl1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tabControl1.ItemSize = new System.Drawing.Size(503, 60);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1512, 499);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl1.TabIndex = 1;
            // 
            // MainForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.ClientSize = new System.Drawing.Size(1512, 499);
            this.Controls.Add(this.tabControl1);
            this.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "MainForm";
            this.Text = "Закупка и Продажа";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.tabPageCounterparty.ResumeLayout(false);
            this.InputCounterparty.ResumeLayout(false);
            this.InputCounterparty.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridCounterparty)).EndInit();
            this.tabPageTransaction.ResumeLayout(false);
            this.panelTransaction.ResumeLayout(false);
            this.panelTransaction.PerformLayout();
            this.groupBoxCP.ResumeLayout(false);
            this.groupBoxCP.PerformLayout();
            this.groupBoxInvoice.ResumeLayout(false);
            this.groupBoxInvoice.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridReceivedProducts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panelOrder.ResumeLayout(false);
            this.panelOrder.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panelMenu.ResumeLayout(false);
            this.panelMenu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridTrsnsaction)).EndInit();
            this.tabPageWarehouse.ResumeLayout(false);
            this.panelProduct.ResumeLayout(false);
            this.panelProduct.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBarcode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPhote)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridWareHouse)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.OpenFileDialog openFileDialogPhotePath;
        private System.Windows.Forms.OpenFileDialog openFileDialogBarCode;
        private System.Windows.Forms.ComboBox comboBoxCPorder;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox textBoxCountListOrder;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.DateTimePicker dateTimePickerOrder;
        private System.Windows.Forms.Button buttonAddCPorder;
        private System.Windows.Forms.Button buttonNextOrder;
        private System.Windows.Forms.Button buttonRemoveOrder;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Button buttonAddInvoice;
        private System.Windows.Forms.Button buttonAddOrder;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnProduct;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnDeliveDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn columnSupplier;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTrans;
        private System.Windows.Forms.Button buttonSaveCP;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button buttonRemoveCP;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TabPage tabPageCounterparty;
        private System.Windows.Forms.Panel InputCounterparty;
        private System.Windows.Forms.MaskedTextBox tBPhone;
        private System.Windows.Forms.Button btnRemoveCP;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tBINN;
        private System.Windows.Forms.Label labelAcc;
        private System.Windows.Forms.TextBox tBBancAcc;
        private System.Windows.Forms.Label labelbankName;
        private System.Windows.Forms.TextBox tBNameBank;
        private System.Windows.Forms.Label labelEmail;
        private System.Windows.Forms.TextBox tBEmail;
        private System.Windows.Forms.Label labelPhone;
        private System.Windows.Forms.Label labelAddress;
        private System.Windows.Forms.TextBox tBAddress;
        private System.Windows.Forms.Label labelFullNameDirector;
        private System.Windows.Forms.TextBox tBFullNameDirector;
        private System.Windows.Forms.Label labelCountry;
        private System.Windows.Forms.TextBox tBCountry;
        private System.Windows.Forms.Label labelFirmName;
        private System.Windows.Forms.TextBox tBFirmName;
        private System.Windows.Forms.Button buttonSaveCounterparty;
        private System.Windows.Forms.Button BtnAddCounterparty;
        private System.Windows.Forms.DataGridView GridCounterparty;
        private System.Windows.Forms.Panel panelTransaction;
        private System.Windows.Forms.Button buttonRemoveInvoice;
        private System.Windows.Forms.Button buttonSaveTransaction;
        private System.Windows.Forms.Button buttonAddNewCp;
        private System.Windows.Forms.DateTimePicker dateTimTransaction;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox comboBoxCounterpartyTransaction;
        private System.Windows.Forms.TabPage tabPageWarehouse;
        public System.Windows.Forms.Panel panelProduct;
        private System.Windows.Forms.ComboBox comboBoxUnit;
        private System.Windows.Forms.PictureBox pictureBoxBarcode;
        private System.Windows.Forms.PictureBox pictureBoxPhote;
        private System.Windows.Forms.ComboBox comboBoxProductGroup;
        private System.Windows.Forms.Button buttonBarcode;
        private System.Windows.Forms.Button buttonRemoveProduct;
        private System.Windows.Forms.Button buttonSaveProduct;
        private System.Windows.Forms.Button btnPhotoPath;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateTimePickerDeliveryDate;
        private System.Windows.Forms.Label labelDeliveryDate;
        private System.Windows.Forms.Label labelgroup;
        private System.Windows.Forms.TextBox textBoxPurchasePrice;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxCountProduct;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxManufactory;
        private System.Windows.Forms.Label labelManufuc;
        private System.Windows.Forms.TextBox textBoxShelfLife;
        private System.Windows.Forms.Label labelDelDate;
        private System.Windows.Forms.TextBox textBoxNameProduct;
        private System.Windows.Forms.Label labelNamePr;
        private System.Windows.Forms.DataGridView GridWareHouse;
        private System.Windows.Forms.Button buttonAddProduct;
        public System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.Label labelCP;
        private System.Windows.Forms.Label labelDate;
        private System.Windows.Forms.Button buttonAddTrans;
        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxPhone;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxINNCP;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxBankAccCP;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxBankNameCP;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBoxEmailCP;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBoxAddress;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBoxFullName;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox textBoxFirmNameCP;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridView GridTrsnsaction;
        private System.Windows.Forms.ComboBox comboBoxUnitInvoice;
        private System.Windows.Forms.Button buttonBarcodeInvoice;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.ComboBox comboBoxGroupInvoice;
        private System.Windows.Forms.TextBox textBoxManufactInvoice;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Button buttonDeleteProductList;
        private System.Windows.Forms.TextBox textBoxShelfLifeINvoice;
        private System.Windows.Forms.TextBox textBoxNameProductInvoice;
        private System.Windows.Forms.Button buttonPhotoInvoice;
        private System.Windows.Forms.Button buttonNextProduct;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.GroupBox groupBoxInvoice;
        private System.Windows.Forms.TextBox textBoxPriceInvoice;
        private System.Windows.Forms.TextBox textBoxCountInvoice;
        private System.Windows.Forms.Button buttonCompleteOrder;
        private System.Windows.Forms.Button buttonRemoveProductOrder;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelTitleProduct;
        private System.Windows.Forms.Button buttonDeleteProduct;
        private System.Windows.Forms.GroupBox panelOrder;
        private System.Windows.Forms.DataGridView gridReceivedProducts;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.GroupBox groupBoxCP;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox textBoxCountryCP;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label53;
        public System.Windows.Forms.TabPage tabPageTransaction;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewImageColumn Column9;
        private System.Windows.Forms.DataGridViewImageColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnFirmName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnCountry;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnDirectorName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnLegalAddress;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnPhone;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnEmail;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnBankName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnBankAccount;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnINN;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumType;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnCP;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnProductName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnProductGroup;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnDeliveryDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnShelfLife;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnManufacturer;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnUnit;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnPurchasePrice;
        private System.Windows.Forms.DataGridViewImageColumn ColumnBarcode;
        private System.Windows.Forms.DataGridViewImageColumn ColumnPhotoPath;
        private System.Windows.Forms.Button buttonLeaveTransaction;
        private System.Windows.Forms.Button buttondeleteTransaction;
    }
}

