﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Курсовая_Работа
{
    static class Data
    {
        public static List<Counterparty> base_Counterparty = new List<Counterparty> { };
        public static List<Order> base_Order = new List<Order> { };
        public static List<Invoice> base_Invoice = new List<Invoice> { };
        public static List<Product> base_Product = new List<Product> { };
    }
}
